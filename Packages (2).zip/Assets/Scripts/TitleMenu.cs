using UnityEngine;
using UnityEngine.SceneManagement; // <-- 이게 꼭 있어야 합니다!

public class TitleMenu : MonoBehaviour
{
    public string gameSceneName = "Stage_1";

    public void OnClickStart()
    {
        Debug.Log("Start 버튼 클릭됨!"); // 콘솔 확인용
        SceneManager.LoadScene(gameSceneName);
        // 또는 SceneManager.LoadScene("Stage_1");
    }

    public void OnClickExit()
    {
        Debug.Log("Exit 버튼 클릭됨!");
        #if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
        #else
            Application.Quit();
        #endif
    }
}