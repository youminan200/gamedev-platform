using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Boulder : MonoBehaviour
{
    [SerializeField] private float rollSpeed = 8f;   // 굴러오는 속도
    [SerializeField] private float lifeTime = 7f;    // 생성 후 사라질 시간(초)

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        // 일정 시간이 지나면 메모리 관리를 위해 자동 삭제
        Destroy(gameObject, lifeTime);
    }

    void FixedUpdate()
    {
        // 결승선 방향(Z축 +)에서 시작점 방향(Z축 -)으로 굴러가도록 힘 전달
        rb.AddForce(Vector3.back * rollSpeed, ForceMode.Acceleration);
    }
}