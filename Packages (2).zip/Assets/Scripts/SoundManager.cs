using UnityEngine;

public class SoundManager : MonoBehaviour
{
    public static SoundManager Instance { get; private set; }

    [Header("오디오 소스")]
    [SerializeField] private AudioSource bgmSource;
    [SerializeField] private AudioSource sfxSource;

    [Header("오디오 클립")]
    [SerializeField] private AudioClip bgmClip;
    [SerializeField] private AudioClip coinClip;
    [SerializeField] private AudioClip jumpClip;
    [SerializeField] private AudioClip hitClip;
    [SerializeField] private AudioClip clearClip; // 클리어 팡파레

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); // 씬이 바뀌어도 음악 유지
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        PlayBGM();
    }

    // BGM 재생 (반복 재생)
    public void PlayBGM()
    {
        if (bgmSource != null && bgmClip != null)
        {
            bgmSource.clip = bgmClip;
            bgmSource.loop = true;
            bgmSource.Play();
        }
    }

    // BGM 정지
    public void StopBGM()
    {
        if (bgmSource != null)
        {
            bgmSource.Stop();
        }
    }

    // 코인 획득 효과음
    public void PlayCoin()
    {
        PlaySFX(coinClip);
    }

    // 점프 효과음
    public void PlayJump()
    {
        PlaySFX(jumpClip);
    }

    // 장애물 피격 효과음
    public void PlayHit()
    {
        PlaySFX(hitClip);
    }

    // 골인 클리어 팡파레
    public void PlayClear()
    {
        PlaySFX(clearClip);
    }

    private void PlaySFX(AudioClip clip)
    {
        if (sfxSource != null && clip != null)
        {
            sfxSource.PlayOneShot(clip);
        }
    }
}