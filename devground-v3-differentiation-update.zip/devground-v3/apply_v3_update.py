#!/usr/bin/env python3
"""
DevGround v3.0 Differentiation Update Installer
Copies the upgraded v3.0 files into your local gamedev-platform repository.
Run from the root of gamedev-platform:
  python apply_v3_update.py
"""
import os
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent

FILES = [
    ("server/src/baas/router.ts", "server/src/baas/router.ts"),
    ("expo-client/src/api/ApiClient.ts", "expo-client/src/api/ApiClient.ts"),
    ("expo-client/src/screens/PostingScreen.tsx", "expo-client/src/screens/PostingScreen.tsx"),
    ("expo-client/src/screens/MainFeedScreen.tsx", "expo-client/src/screens/MainFeedScreen.tsx"),
]

def main():
    backup_dir = ROOT / ".v3-backup"
    backup_dir.mkdir(exist_ok=True)
    for src_rel, dst_rel in FILES:
        src = ROOT / src_rel
        dst = Path.cwd() / dst_rel
        if dst.exists():
            bak = backup_dir / dst_rel.replace("/", "_")
            shutil.copy2(dst, bak)
            print(f"[BACKUP] {dst_rel} -> {bak}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        print(f"[UPDATED] {dst_rel}")
    print("\n✅ DevGround v3.0 차별화 업데이트 파일 반영 완료!")
    print("다음 명령어로 GitHub에 푸시하면 Vercel & Render에 즉시 배포됩니다:")
    print("  git add server/src/baas/router.ts expo-client/src/api/ApiClient.ts expo-client/src/screens/PostingScreen.tsx expo-client/src/screens/MainFeedScreen.tsx")
    print('  git commit -m "feat(v3.0): add PlayLoop BaaS console, in-game timestamped playtest pins, recipe graph, and 48h gamejam wishlist arena"')
    print("  git push origin main")

if __name__ == "__main__":
    main()
