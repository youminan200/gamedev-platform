using UnityEngine;
using UnityEngine.InputSystem; // 신규 Input System 네임스페이스 추가
using UnityEngine.SceneManagement;

public class PauseManager : MonoBehaviour
{
    [Header("일시정지 팝업 패널")]
    [SerializeField] private GameObject pausePanel;

    private bool isPaused = false;

    void Start()
    {
        // 시작할 때는 일시정지 창을 숨김
        if (pausePanel != null)
        {
            pausePanel.SetActive(false);
        }
        Time.timeScale = 1f; // 게임 시간 정상 흐름 보장
    }

    void Update()
    {
        // 신규 Input System 방식으로 ESC 키 감지
        if (Keyboard.current != null && Keyboard.current.escapeKey.wasPressedThisFrame)
        {
            if (isPaused)
            {
                Resume();
            }
            else
            {
                Pause();
            }
        }
    }

    public void Pause()
    {
        isPaused = true;
        if (pausePanel != null)
        {
            pausePanel.SetActive(true);
        }
        Time.timeScale = 0f; // 물리 연산 및 시간 정지
    }

    public void Resume()
    {
        isPaused = false;
        if (pausePanel != null)
        {
            pausePanel.SetActive(false);
        }
        Time.timeScale = 1f; // 시간 정상화
    }

    public void Restart()
    {
        Time.timeScale = 1f; // 씬 전환 전 시간 복구 필수
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void GoToTitle()
    {
        Time.timeScale = 1f; // 시간 복구
        SceneManager.LoadScene("TitleScene");
    }
}