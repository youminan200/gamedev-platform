using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(Rigidbody))]
public class PlayerController : MonoBehaviour
{
    [Header("이동 속도")]
    [SerializeField] private float moveSpeed = 7f;
    [SerializeField] private float jumpForce = 6f;
    [SerializeField] private float fallThreshold = -5f;

    [Header("피격 넉백")]
    [SerializeField] private float knockbackForce = 12f;
    [SerializeField] private float knockbackDuration = 0.4f;

    private Rigidbody rb;
    private float moveX;
    private float moveZ;
    private bool isGrounded;
    private bool isKnockedBack = false;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.freezeRotation = true;
    }

    void Update()
    {
        // 1. 낙사 체크
        if (transform.position.y < fallThreshold)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            return;
        }

        if (isKnockedBack) return;

        // 2. 키보드 이동 입력
        moveX = 0f;
        moveZ = 0f;

        if (Keyboard.current != null)
        {
            if (Keyboard.current.aKey.isPressed || Keyboard.current.leftArrowKey.isPressed)
                moveX -= 1f;
            if (Keyboard.current.dKey.isPressed || Keyboard.current.rightArrowKey.isPressed)
                moveX += 1f;
            if (Keyboard.current.wKey.isPressed || Keyboard.current.upArrowKey.isPressed)
                moveZ += 1f;
            if (Keyboard.current.sKey.isPressed || Keyboard.current.downArrowKey.isPressed)
                moveZ -= 1f;

            // 3. 점프 입력 및 점프 사운드 재생
            if (Keyboard.current.spaceKey.wasPressedThisFrame && isGrounded)
            {
                rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
                isGrounded = false;

                // 점프 효과음 재생
                if (SoundManager.Instance != null)
                {
                    SoundManager.Instance.PlayJump();
                }
            }
        }
    }

    void FixedUpdate()
    {
        if (isKnockedBack) return;

        Vector3 targetVelocity = new Vector3(
            moveX * moveSpeed,
            rb.linearVelocity.y,
            moveZ * moveSpeed
        );

        rb.linearVelocity = targetVelocity;
    }

    private void OnCollisionEnter(Collision collision)
    {
        // 바닥 충돌 감지 (태그 검사 에러를 피하기 위해 이름 검사 사용)
        if (collision.gameObject.name.Contains("Track"))
        {
            isGrounded = true;
        }

        // 장애물 피격 넉백
        if (collision.gameObject.CompareTag("Obstacle") && !isKnockedBack)
        {
            Vector3 pushDirection = (transform.position - collision.transform.position).normalized;
            pushDirection.y = 0.5f;

            rb.linearVelocity = Vector3.zero;
            rb.AddForce(pushDirection.normalized * knockbackForce, ForceMode.Impulse);

            isKnockedBack = true;

            // 피격 효과음 재생 (HitClip이 등록되어 있으면 재생됨)
            if (SoundManager.Instance != null)
            {
                SoundManager.Instance.PlayHit();
            }

            Invoke(nameof(RecoverFromKnockback), knockbackDuration);
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        // 바닥에서 떨어졌을 때 점프 불가 처리
        if (collision.gameObject.name.Contains("Track"))
        {
            isGrounded = false;
        }
    }

    private void RecoverFromKnockback()
    {
        isKnockedBack = false;
    }
}