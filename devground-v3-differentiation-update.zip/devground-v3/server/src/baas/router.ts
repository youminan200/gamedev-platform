import { Router, Request, Response, NextFunction } from 'express';
import Database from 'better-sqlite3';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'devground_super_secret';
const router = Router();

// SQLite Dual-Engine Support (Zero-Config 24/7 operation even when DATABASE_URL is not set)
const sqliteDb = new Database(process.env.SQLITE_PATH || 'database.sqlite');

sqliteDb.exec(`
  CREATE TABLE IF NOT EXISTS baas_games (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    engine TEXT DEFAULT 'Unity',
    developer_id TEXT NOT NULL,
    api_key TEXT UNIQUE NOT NULL,
    steam_url TEXT,
    devlog_id TEXT,
    used_cartridges TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS baas_builds (
    id TEXT PRIMARY KEY,
    game_id TEXT NOT NULL,
    version TEXT NOT NULL,
    platform TEXT NOT NULL,
    artifact_url TEXT NOT NULL,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS baas_leaderboards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    game_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    username TEXT NOT NULL,
    score INTEGER NOT NULL,
    metadata TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS baas_feedbacks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    game_id TEXT NOT NULL,
    build_ver TEXT DEFAULT 'v1.0.0',
    type TEXT DEFAULT 'REVIEW',
    timestamp_pin TEXT DEFAULT '00:45',
    message TEXT NOT NULL,
    author TEXT DEFAULT 'Playtester',
    device_info TEXT DEFAULT 'WebGL',
    upvotes INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS baas_cloud_saves (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    game_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    slot_key TEXT DEFAULT 'slot_1',
    save_json TEXT NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(game_id, user_id, slot_key)
  );
`);

// Seed default showcase games into PlayLoop BaaS if empty
const gameCount = (sqliteDb.prepare('SELECT COUNT(*) as cnt FROM baas_games').get() as any)?.cnt || 0;
if (gameCount === 0) {
  const seedGames = [
    {
      id: 'game_shadow',
      title: 'Shadow Dungeon: 심연의 검',
      slug: 'shadow-dungeon',
      engine: 'Unity',
      developer_id: 'PixelKnight',
      api_key: 'dg_live_shadow_9f8a7b6c5d4e',
      steam_url: 'https://store.steampowered.com',
      devlog_id: '1',
      used_cartridges: 'MOD_01 도트스튜디오,MOD_04 8비트효과음,MOD_11 셰이더사전,MOD_23 역경직계산기'
    },
    {
      id: 'game_cozy',
      title: 'Cozy Farm Island: 포근한 도트 농장',
      slug: 'cozy-farm-island',
      engine: 'Godot',
      developer_id: 'GodotCrafter',
      api_key: 'dg_live_cozy_3e2d1c0b9a8f',
      steam_url: 'https://itch.io',
      devlog_id: '3',
      used_cartridges: 'MOD_05 칩튠브금,MOD_12 다국어번역,MOD_14 대사창에디터'
    },
    {
      id: 'game_arena',
      title: 'Cyber Arena 2099: 네온 메카 서바이벌',
      slug: 'cyber-arena-2099',
      engine: 'Unreal',
      developer_id: 'ShaderWizard',
      api_key: 'dg_live_arena_7c6b5a4f3e2d',
      steam_url: 'https://store.steampowered.com',
      devlog_id: '2',
      used_cartridges: 'MOD_08 밸런스계산기,MOD_21 보스FSM,MOD_27 웨이브스포너'
    }
  ];

  const insGame = sqliteDb.prepare(
    'INSERT INTO baas_games (id, title, slug, engine, developer_id, api_key, steam_url, devlog_id, used_cartridges) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
  );
  for (const g of seedGames) {
    insGame.run(g.id, g.title, g.slug, g.engine, g.developer_id, g.api_key, g.steam_url, g.devlog_id, g.used_cartridges);
  }

  const insLb = sqliteDb.prepare(
    'INSERT INTO baas_leaderboards (game_id, user_id, username, score, metadata) VALUES (?, ?, ?, ?, ?)'
  );
  insLb.run('game_shadow', 'u1', 'PixelKnight', 18450, JSON.stringify({ stage: 'Boss 4F', weapon: 'AbyssBlade' }));
  insLb.run('game_shadow', 'u2', 'RogueMaster', 15920, JSON.stringify({ stage: 'Floor 3F', weapon: 'TwinDagger' }));
  insLb.run('game_shadow', 'u3', 'DotSlayer', 12300, JSON.stringify({ stage: 'Floor 2F', weapon: 'FireStaff' }));
  insLb.run('game_cozy', 'u4', 'GodotCrafter', 9800, JSON.stringify({ day: 'Autumn Day 14', crop: 'GoldenPumpkin' }));
  insLb.run('game_arena', 'u5', 'ShaderWizard', 34200, JSON.stringify({ wave: 'Wave 19', mech: 'Valkyrie-X' }));

  const insFb = sqliteDb.prepare(
    'INSERT INTO baas_feedbacks (game_id, build_ver, type, timestamp_pin, message, author, device_info, upvotes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  );
  insFb.run('game_shadow', 'v0.4.2-web', 'REVIEW', '00:42 · 1층 슬라임 웨이브', '역경직(Hitstop) 0.08초 세팅 덕분에 평타 3타 맞출 때 손맛이 진짜 쫀득합니다!', 'IndieTester_KR', 'WebGL / Chrome', 7);
  insFb.run('game_shadow', 'v0.4.2-web', 'SUGGESTION', '01:28 · 보스방 진입 직전', '대시 쿨타임 인디케이터가 캐릭터 발밑에도 작게 표시되면 탄막 피할 때 시선 처리가 훨씬 편할 것 같아요.', 'RogueFan99', 'WebGL / Edge', 5);
  insFb.run('game_shadow', 'v0.4.2-web', 'BUG', '02:05 · 우측 상단 보물상자', '벽에 딱 붙어서 대시 공격을 쓰면 간헐적으로 타일 콜라이더 모서리에 0.5초 정도 끼입니다.', 'QA_Hunter', 'WebGL / Desktop', 3);
}

function devAuthOptional(req: any, _res: Response, next: NextFunction) {
  const token = req.headers['authorization']?.split(' ')[1];
  if (token) {
    try {
      req.user = jwt.verify(token, JWT_SECRET);
    } catch {}
  }
  if (!req.user) {
    req.user = { id: 'guest_dev', username: req.body?.developer || 'IndieCreator' };
  }
  next();
}

function apiKeyOrSlugAuth(req: any, res: Response, next: NextFunction) {
  const key = req.headers['x-api-key'] || req.query.apiKey || req.body?.apiKey;
  const slug = req.query.slug || req.body?.slug || req.params.slug;
  let game: any = null;
  if (key) {
    game = sqliteDb.prepare('SELECT * FROM baas_games WHERE api_key = ?').get(String(key));
  }
  if (!game && slug) {
    game = sqliteDb.prepare('SELECT * FROM baas_games WHERE slug = ? OR id = ?').get(String(slug), String(slug));
  }
  if (!game) {
    game = sqliteDb.prepare('SELECT * FROM baas_games ORDER BY created_at ASC LIMIT 1').get();
  }
  if (!game) return res.status(404).json({ error: 'Game not found' });
  req.game = game;
  next();
}

const slugify = (s: string) =>
  s.toLowerCase().trim().replace(/[^a-z0-9가-힣]+/g, '-').replace(/^-+|-+$/g, '') || 'indie-game';

// 1. 개발자용: 내 BaaS 게임 목록 및 전체 등록 게임 조회
router.get('/games', (_req: Request, res: Response) => {
  const games = sqliteDb.prepare('SELECT * FROM baas_games ORDER BY created_at DESC').all();
  res.json(games);
});

router.get('/games/mine', devAuthOptional, (req: any, res: Response) => {
  const games = sqliteDb.prepare('SELECT * FROM baas_games ORDER BY created_at DESC').all();
  res.json(games);
});

// 2. 신규 게임 등록 & 고유 X-API-Key 즉시 발급
router.post('/games', devAuthOptional, (req: any, res: Response) => {
  const { title, slug, engine, steam_url, devlog_id, used_cartridges } = req.body || {};
  if (!title) return res.status(400).json({ error: 'title required' });
  const baseSlug = slug ? slugify(slug) : slugify(title);
  const uniqueSlug = `${baseSlug}-${Math.floor(100 + Math.random() * 900)}`;
  const id = 'game_' + crypto.randomBytes(4).toString('hex');
  const apiKey = 'dg_live_' + crypto.randomBytes(8).toString('hex');
  const devId = String(req.user?.username || req.user?.id || 'IndieCreator');

  sqliteDb.prepare(
    'INSERT INTO baas_games (id, title, slug, engine, developer_id, api_key, steam_url, devlog_id, used_cartridges) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(
    id,
    String(title).trim(),
    uniqueSlug,
    String(engine || 'Unity'),
    devId,
    apiKey,
    steam_url ? String(steam_url) : null,
    devlog_id ? String(devlog_id) : null,
    used_cartridges ? String(used_cartridges) : 'MOD_01 도트스튜디오,MOD_04 8비트효과음'
  );

  const created = sqliteDb.prepare('SELECT * FROM baas_games WHERE id = ?').get(id);
  res.status(201).json(created);
});

// 3. 공개 텔레메트리 조회 (특정 게임의 실시간 리더보드 + 타임스탬프 인게임 피드백 + 제작 레시피)
router.get('/public/games/:slug/telemetry', (req: Request, res: Response) => {
  const slug = String(req.params.slug || 'shadow-dungeon');
  let game: any = sqliteDb.prepare('SELECT * FROM baas_games WHERE slug = ? OR id = ?').get(slug, slug);
  if (!game) {
    game = sqliteDb.prepare('SELECT * FROM baas_games ORDER BY created_at ASC LIMIT 1').get();
  }
  if (!game) return res.status(404).json({ error: 'Game not found' });

  const leaderboard = sqliteDb.prepare(
    'SELECT id, user_id as userId, username, MAX(score) as score, metadata, created_at as createdAt FROM baas_leaderboards WHERE game_id = ? GROUP BY username ORDER BY score DESC LIMIT 20'
  ).all(game.id).map((row: any, idx: number) => ({
    rank: idx + 1,
    ...row,
    metadata: (() => { try { return JSON.parse(row.metadata || '{}'); } catch { return {}; } })()
  }));

  const feedbacks = sqliteDb.prepare(
    'SELECT id, game_id as gameId, build_ver as buildVer, type, timestamp_pin as timestampPin, message, author, device_info as deviceInfo, upvotes, created_at as createdAt FROM baas_feedbacks WHERE game_id = ? ORDER BY id DESC LIMIT 50'
  ).all(game.id);

  res.json({
    game,
    leaderboard,
    feedbacks
  });
});

// 4. 리더보드 점수 등록 & 조회 (Unity / Godot SDK & Web Demo 겸용)
router.post('/leaderboard', apiKeyOrSlugAuth, (req: any, res: Response) => {
  const { userId, username, score, metadata } = req.body || {};
  const numericScore = Number(score);
  if (!username || !Number.isFinite(numericScore)) {
    return res.status(400).json({ error: 'username and numeric score required' });
  }
  const info = sqliteDb.prepare(
    'INSERT INTO baas_leaderboards (game_id, user_id, username, score, metadata) VALUES (?, ?, ?, ?, ?)'
  ).run(
    req.game.id,
    String(userId || username),
    String(username).slice(0, 32),
    numericScore,
    metadata ? JSON.stringify(metadata) : null
  );
  res.status(201).json({ id: info.lastInsertRowid, gameId: req.game.id, username, score: numericScore });
});

router.get('/leaderboard', apiKeyOrSlugAuth, (req: any, res: Response) => {
  const rows = sqliteDb.prepare(
    'SELECT id, user_id as userId, username, MAX(score) as score, metadata, created_at as createdAt FROM baas_leaderboards WHERE game_id = ? GROUP BY username ORDER BY score DESC LIMIT 20'
  ).all(req.game.id);
  res.json(rows.map((r: any, i: number) => ({ rank: i + 1, ...r })));
});

// 5. 인게임 타임스탬프 피드백 & 버그 핀 등록 (웹 쇼케이스 & 게임 엔진 SDK 겸용)
router.post('/feedback', apiKeyOrSlugAuth, (req: any, res: Response) => {
  const { buildVer, type, timestampPin, message, author, deviceInfo } = req.body || {};
  if (!message || !String(message).trim()) {
    return res.status(400).json({ error: 'message required' });
  }
  const normType = String(type || 'REVIEW').toUpperCase();
  const validType = ['BUG', 'SUGGESTION', 'REVIEW'].includes(normType) ? normType : 'REVIEW';

  const info = sqliteDb.prepare(
    'INSERT INTO baas_feedbacks (game_id, build_ver, type, timestamp_pin, message, author, device_info) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run(
    req.game.id,
    String(buildVer || 'v1.0-web'),
    validType,
    String(timestampPin || '00:45 · 인게임 플레이'),
    String(message).trim(),
    String(author || 'IndieTester'),
    String(deviceInfo || 'WebGL Player')
  );

  const created = sqliteDb.prepare(
    'SELECT id, game_id as gameId, build_ver as buildVer, type, timestamp_pin as timestampPin, message, author, device_info as deviceInfo, upvotes, created_at as createdAt FROM baas_feedbacks WHERE id = ?'
  ).get(info.lastInsertRowid);

  res.status(201).json(created);
});

// 6. 클라우드 세이브 API (Unity / Godot 크로스플랫폼 JSON 세이브 동기화)
router.post('/cloud-save', apiKeyOrSlugAuth, (req: any, res: Response) => {
  const { userId, slotKey, saveData } = req.body || {};
  if (!userId || saveData === undefined) {
    return res.status(400).json({ error: 'userId and saveData required' });
  }
  const slot = String(slotKey || 'slot_1');
  const payload = typeof saveData === 'string' ? saveData : JSON.stringify(saveData);

  sqliteDb.prepare(`
    INSERT INTO baas_cloud_saves (game_id, user_id, slot_key, save_json, updated_at)
    VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(game_id, user_id, slot_key)
    DO UPDATE SET save_json = excluded.save_json, updated_at = CURRENT_TIMESTAMP
  `).run(req.game.id, String(userId), slot, payload);

  res.json({ ok: true, gameId: req.game.id, userId, slotKey: slot });
});

router.get('/cloud-save', apiKeyOrSlugAuth, (req: any, res: Response) => {
  const userId = String(req.query.userId || '');
  const slot = String(req.query.slotKey || 'slot_1');
  if (!userId) return res.status(400).json({ error: 'userId query required' });

  const row: any = sqliteDb.prepare(
    'SELECT save_json, updated_at FROM baas_cloud_saves WHERE game_id = ? AND user_id = ? AND slot_key = ?'
  ).get(req.game.id, userId, slot);

  if (!row) return res.status(404).json({ error: 'Save slot empty' });
  res.json({
    gameId: req.game.id,
    userId,
    slotKey: slot,
    updatedAt: row.updated_at,
    saveData: (() => { try { return JSON.parse(row.save_json); } catch { return row.save_json; } })()
  });
});

export default router;
