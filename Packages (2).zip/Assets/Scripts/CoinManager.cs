using UnityEngine;
using TMPro; // TextMeshPro 사용

public class CoinManager : MonoBehaviour
{
    public static CoinManager Instance { get; private set; }

    [Header("코인 표시 텍스트 UI")]
    [SerializeField] private TextMeshProUGUI coinText;

    private int coinCount = 0;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        UpdateCoinUI();
    }

    // 코인을 획득했을 때 호출할 함수
    public void AddCoin(int amount = 1)
    {
        coinCount += amount;
        UpdateCoinUI();
    }

    // UI 텍스트 갱신
    private void UpdateCoinUI()
    {
        if (coinText != null)
        {
            coinText.text = $"COIN : {coinCount}";
        }
    }
}