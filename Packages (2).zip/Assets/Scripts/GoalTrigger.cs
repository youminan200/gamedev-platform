using UnityEngine;
using UnityEngine.SceneManagement;

public class GoalTrigger : MonoBehaviour
{
    // 이동할 다음 스테이지 이름 (Scene List에 등록된 Stage_2)
    [SerializeField] private string nextSceneName = "Stage_2";

    private void OnTriggerEnter(Collider other)
    {
        // 최적화: tag 직접 비교 대신 CompareTag 사용
        if (other.CompareTag("Player"))
        {
            Debug.Log("Goal In! 다음 스테이지로 이동합니다.");
            SceneManager.LoadScene(nextSceneName);
        }
    }
}