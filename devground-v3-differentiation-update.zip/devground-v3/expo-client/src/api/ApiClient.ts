import { DevLog, DevLogCreateRequest } from '../models/DevLog';
import { Platform } from 'react-native';

const BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'https://gamedev-platform.onrender.com/api';

const TOKEN_KEY = 'devground_auth_token';
const USERNAME_KEY = 'devground_username';

const getStorageItem = (key: string): string | null => {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      return window.localStorage.getItem(key);
    }
  } catch {}
  return null;
};

const setStorageItem = (key: string, value: string | null) => {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      if (value === null) {
        window.localStorage.removeItem(key);
      } else {
        window.localStorage.setItem(key, value);
      }
    }
  } catch {}
};

let authToken: string | null = getStorageItem(TOKEN_KEY);
let savedUsername: string | null = getStorageItem(USERNAME_KEY);

export const ApiClient = {
  setToken: (token: string | null) => {
    authToken = token;
    setStorageItem(TOKEN_KEY, token);
  },

  getToken: () => authToken,

  setUsername: (username: string | null) => {
    savedUsername = username;
    setStorageItem(USERNAME_KEY, username);
  },

  getUsername: () => savedUsername,

  logout: () => {
    authToken = null;
    savedUsername = null;
    setStorageItem(TOKEN_KEY, null);
    setStorageItem(USERNAME_KEY, null);
  },

  decodeTokenUsername: (token: string): string | null => {
    try {
      const base64Url = token.split('.')[1];
      if (!base64Url) return null;
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(
        atob(base64)
          .split('')
          .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
          .join('')
      );
      const parsed = JSON.parse(jsonPayload);
      return parsed.username || null;
    } catch {
      return null;
    }
  },

  getHeaders: () => {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (authToken) {
      headers['Authorization'] = `Bearer ${authToken}`;
    }
    return headers;
  },

  login: async (username: string, password: string):Promise<any> => {
    const response = await fetch(`${BASE_URL}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Failed to login');
    if (data.token) {
      ApiClient.setToken(data.token);
      ApiClient.setUsername(data.user?.username || username);
    }
    return data;
  },

  signup: async (username: string, password: string):Promise<any> => {
    const response = await fetch(`${BASE_URL}/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Failed to sign up');
    if (data.token) {
      ApiClient.setToken(data.token);
      ApiClient.setUsername(data.user?.username || username);
    }
    return data;
  },

  loginWithKakao: async (accessToken: string): Promise<any> => {
    const response = await fetch(`${BASE_URL}/auth/kakao`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ accessToken })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Failed to login with Kakao');
    if (data.token) {
      ApiClient.setToken(data.token);
      const decodedUser = ApiClient.decodeTokenUsername(data.token);
      if (decodedUser) ApiClient.setUsername(decodedUser);
    }
    return data;
  },

  getDevLogs: async (search?: string, tag?: string): Promise<DevLog[]> => {
    const params = new URLSearchParams();
    if (search) params.append('search', search);
    if (tag) params.append('tag', tag);
    const queryString = params.toString() ? `?${params.toString()}` : '';

    const response = await fetch(`${BASE_URL}/devlogs${queryString}`, { headers: ApiClient.getHeaders() });
    if (!response.ok) throw new Error('Failed to fetch devlogs');
    return response.json();
  },

  getDevLogDetails: async (id: string): Promise<any> => {
    const response = await fetch(`${BASE_URL}/devlogs/${id}`, { headers: ApiClient.getHeaders() });
    if (!response.ok) throw new Error('Failed to fetch devlog details');
    return response.json();
  },

  postDevLog: async (request: any): Promise<DevLog> => {
    const response = await fetch(`${BASE_URL}/devlogs`, {
      method: 'POST',
      headers: ApiClient.getHeaders(),
      body: JSON.stringify(request),
    });
    if (!response.ok) throw new Error('Failed to post devlog');
    return response.json();
  },

  updateDevLog: async (id: string, request: any): Promise<any> => {
    const response = await fetch(`${BASE_URL}/devlogs/${id}`, {
      method: 'PUT',
      headers: ApiClient.getHeaders(),
      body: JSON.stringify(request),
    });
    if (!response.ok) throw new Error('Failed to update devlog');
    return response.json();
  },

  deleteDevLog: async (id: string): Promise<any> => {
    const response = await fetch(`${BASE_URL}/devlogs/${id}`, {
      method: 'DELETE',
      headers: ApiClient.getHeaders(),
    });
    if (!response.ok) throw new Error('Failed to delete devlog');
    return response.json();
  },

  toggleLikeDevLog: async (id: string): Promise<{ liked: boolean; likes: number }> => {
    const response = await fetch(`${BASE_URL}/devlogs/${id}/like`, {
      method: 'POST',
      headers: ApiClient.getHeaders(),
    });
    if (!response.ok) throw new Error('Failed to toggle like');
    return response.json();
  },

  postComment: async (devlogId: string, content: string): Promise<any> => {
    const response = await fetch(`${BASE_URL}/devlogs/${devlogId}/comments`, {
      method: 'POST',
      headers: ApiClient.getHeaders(),
      body: JSON.stringify({ content }),
    });
    if (!response.ok) throw new Error('Failed to post comment');
    return response.json();
  },

  deleteComment: async (devlogId: string, commentId: string): Promise<any> => {
    const response = await fetch(`${BASE_URL}/devlogs/${devlogId}/comments/${commentId}`, {
      method: 'DELETE',
      headers: ApiClient.getHeaders(),
    });
    if (!response.ok) throw new Error('Failed to delete comment');
    return response.json();
  },

  // Asset API
  getAssets: async (category?: string, search?: string): Promise<any[]> => {
    const params = new URLSearchParams();
    if (category) params.append('category', category);
    if (search) params.append('search', search);
    const queryString = params.toString() ? `?${params.toString()}` : '';

    const response = await fetch(`${BASE_URL}/assets${queryString}`, { headers: ApiClient.getHeaders() });
    if (!response.ok) throw new Error('Failed to fetch assets');
    return response.json();
  },

  getAssetDetails: async (id: string): Promise<any> => {
    const response = await fetch(`${BASE_URL}/assets/${id}`, { headers: ApiClient.getHeaders() });
    if (!response.ok) throw new Error('Failed to fetch asset details');
    return response.json();
  },

  postAsset: async (assetData: any): Promise<any> => {
    const response = await fetch(`${BASE_URL}/assets`, {
      method: 'POST',
      headers: ApiClient.getHeaders(),
      body: JSON.stringify(assetData),
    });
    if (!response.ok) throw new Error('Failed to post asset');
    return response.json();
  },

  deleteAsset: async (id: string): Promise<any> => {
    const response = await fetch(`${BASE_URL}/assets/${id}`, {
      method: 'DELETE',
      headers: ApiClient.getHeaders(),
    });
    if (!response.ok) throw new Error('Failed to delete asset');
    return response.json();
  },

  postAssetFeedback: async (assetId: string, feedbackData: any): Promise<any> => {
    const response = await fetch(`${BASE_URL}/assets/${assetId}/feedbacks`, {
      method: 'POST',
      headers: ApiClient.getHeaders(),
      body: JSON.stringify(feedbackData),
    });
    if (!response.ok) throw new Error('Failed to submit asset feedback');
    return response.json();
  },

  updateAsset: async (id: string, data: any): Promise<any> => {
    const response = await fetch(`${BASE_URL}/assets/${id}`, {
      method: 'PUT',
      headers: ApiClient.getHeaders(),
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error('Failed to update asset');
    return response.json();
  },

  toggleLikeAsset: async (id: string): Promise<{ liked: boolean; likes: number }> => {
    const response = await fetch(`${BASE_URL}/assets/${id}/like`, {
      method: 'POST',
      headers: ApiClient.getHeaders(),
    });
    if (!response.ok) throw new Error('Failed to toggle asset like');
    return response.json();
  },

  getNotifications: async (): Promise<{ unread: number; items: any[] }> => {
    const response = await fetch(`${BASE_URL}/notifications`, { headers: ApiClient.getHeaders() });
    if (!response.ok) throw new Error('Failed to fetch notifications');
    return response.json();
  },

  markNotificationsRead: async (): Promise<any> => {
    const response = await fetch(`${BASE_URL}/notifications/read`, {
      method: 'POST',
      headers: ApiClient.getHeaders(),
    });
    if (!response.ok) throw new Error('Failed to mark notifications read');
    return response.json();
  },

  markNotificationRead: async (id: string): Promise<any> => {
    const response = await fetch(`${BASE_URL}/notifications/${id}/read`, {
      method: 'POST',
      headers: ApiClient.getHeaders(),
    });
    if (!response.ok) throw new Error('Failed to mark notification read');
    return response.json();
  },

  uploadImageData: async (dataUrl: string): Promise<string> => {
    const response = await fetch(`${BASE_URL}/upload`, {
      method: 'POST',
      headers: ApiClient.getHeaders(),
      body: JSON.stringify({ data: dataUrl }),
    });
    const body = await response.json();
    if (!response.ok) throw new Error(body.error || 'Failed to upload image');
    return body.url;
  },

  // Web-only: open the browser file picker and upload the chosen image. Resolves null if cancelled/unsupported.
  pickAndUploadImage: (): Promise<string | null> => {
    return new Promise((resolve, reject) => {
      if (Platform.OS !== 'web' || typeof document === 'undefined') {
        resolve(null);
        return;
      }
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/png,image/jpeg,image/gif,image/webp';
      input.onchange = () => {
        const file = input.files && input.files[0];
        if (!file) return resolve(null);
        if (file.size > 5 * 1024 * 1024) return reject(new Error('이미지는 5MB 이하만 가능합니다.'));
        const reader = new FileReader();
        reader.onload = async () => {
          try {
            resolve(await ApiClient.uploadImageData(String(reader.result)));
          } catch (e) {
            reject(e);
          }
        };
        reader.onerror = () => reject(new Error('파일을 읽을 수 없습니다.'));
        reader.readAsDataURL(file);
      };
      input.click();
    });
  },

  // Bookmarks (localStorage + in-memory fallback)
  getBookmarks: (type: 'devlog' | 'asset' = 'devlog'): string[] => {
    const raw = getStorageItem(`devground_bookmarks_${type}`);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  toggleBookmark: (id: string, type: 'devlog' | 'asset' = 'devlog'): boolean => {
    const current = ApiClient.getBookmarks(type);
    const exists = current.includes(String(id));
    const next = exists ? current.filter((item) => item !== String(id)) : [...current, String(id)];
    setStorageItem(`devground_bookmarks_${type}`, JSON.stringify(next));
    return !exists;
  },

  isBookmarked: (id: string, type: 'devlog' | 'asset' = 'devlog'): boolean => {
    return ApiClient.getBookmarks(type).includes(String(id));
  },

  // Profile API
  recordAssetDownload: async (id: string): Promise<{ downloads: number }> => {
    const response = await fetch(`${BASE_URL}/assets/${id}/download`, { method: 'POST' });
    if (!response.ok) return { downloads: 1 };
    return await response.json();
  },

  updateUserProfile: async (data: { bio?: string; engine?: string; github_url?: string; steam_url?: string; itch_url?: string; support_url?: string }): Promise<void> => {
    const response = await fetch(`${BASE_URL}/users/profile`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
      },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error('Failed to update profile');
  },

  voteDevLogPoll: async (id: string, option: 'A' | 'B'): Promise<{ poll_votes_a: number; poll_votes_b: number }> => {
    const response = await fetch(`${BASE_URL}/devlogs/${id}/vote`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ option }),
    });
    if (!response.ok) return { poll_votes_a: 0, poll_votes_b: 0 };
    return await response.json();
  },

  getShowcases: async (): Promise<any[]> => {
    const response = await fetch(`${BASE_URL}/showcases`);
    if (!response.ok) return [];
    return await response.json();
  },

  postShowcase: async (data: { title: string; developer: string; engine: string; homepage_url: string; thumbnail_url?: string; description?: string }): Promise<any[]> => {
    const response = await fetch(`${BASE_URL}/showcases`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) return [];
    return await response.json();
  },

  visitShowcase: async (id: number | string): Promise<{ plays: number }> => {
    const response = await fetch(`${BASE_URL}/showcases/${id}/visit`, { method: 'POST' });
    if (!response.ok) return { plays: 1 };
    return await response.json();
  },

  getShoutbox: async (): Promise<any[]> => {
    const response = await fetch(`${BASE_URL}/shoutbox`);
    if (!response.ok) return [];
    return await response.json();
  },

  postShoutbox: async (nickname: string, message: string): Promise<any[]> => {
    const response = await fetch(`${BASE_URL}/shoutbox`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nickname, message }),
    });
    if (!response.ok) return [];
    return await response.json();
  },

  getLeaderboard: async (): Promise<any[]> => {
    const response = await fetch(`${BASE_URL}/leaderboard`);
    if (!response.ok) return [];
    return await response.json();
  },

  getArcadeScores: async (): Promise<any[]> => {
    const response = await fetch(`${BASE_URL}/arcade/scores`);
    if (!response.ok) return [];
    return await response.json();
  },

  getTeams: async (): Promise<any[]> => {
    const response = await fetch(`${BASE_URL}/teams`);
    if (!response.ok) return [];
    return await response.json();
  },

  postTeam: async (data: { project_title: string; role_needed: string; engine: string; author: string; contact_url: string; description: string }): Promise<any[]> => {
    const response = await fetch(`${BASE_URL}/teams`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) return [];
    return await response.json();
  },


  deleteMyAccount: async (): Promise<void> => {
    const response = await fetch(`${BASE_URL}/users/me`, {
      method: 'DELETE',
      headers: ApiClient.getHeaders(),
    });
    if (!response.ok) throw new Error('회원 탈퇴 처리에 실패했습니다.');
    ApiClient.logout();
  },

  reportContent: async (data: { target_type: string; target_id: string; target_author?: string; reason: string; reporter?: string }): Promise<void> => {
    await fetch(`${BASE_URL}/reports`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
  },

  getBlockedUsers: (): string[] => {
    const raw = getStorageItem('devground_blocked_users');
    if (!raw) return [];
    try { return JSON.parse(raw); } catch { return []; }
  },

  blockUser: (targetUsername: string): string[] => {
    const cur = ApiClient.getBlockedUsers();
    if (!cur.includes(targetUsername)) {
      const next = [...cur, targetUsername];
      setStorageItem('devground_blocked_users', JSON.stringify(next));
      return next;
    }
    return cur;
  },

  unblockUser: (targetUsername: string): string[] => {
    const next = ApiClient.getBlockedUsers().filter((u) => u !== targetUsername);
    setStorageItem('devground_blocked_users', JSON.stringify(next));
    return next;
  },


  getErrors: async (): Promise<any[]> => {
    const response = await fetch(`${BASE_URL}/errors`);
    if (!response.ok) return [];
    return await response.json();
  },

  postError: async (data: { engine: string; error_title: string; cause: string; solution: string; code_fix?: string; author?: string }): Promise<any[]> => {
    const response = await fetch(`${BASE_URL}/errors`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) return [];
    return await response.json();
  },

  markErrorHelpful: async (id: number | string): Promise<{ helpful_count: number }> => {
    const response = await fetch(`${BASE_URL}/errors/${id}/helpful`, { method: 'POST' });
    if (!response.ok) return { helpful_count: 1 };
    return await response.json();
  },

  getUserProfile: async (username: string): Promise<any> => {
    const response = await fetch(`${BASE_URL}/users/${username}`, { headers: ApiClient.getHeaders() });
    if (!response.ok) throw new Error('Failed to fetch user profile');
    return response.json();
  },

  // ── v3.0 Cross-Cartridge 1-Click DevLog Draft Bridge ──
  setPendingDraft: (draft: { title: string; content: string; tags?: string[]; pollQuestion?: string; pollOptionA?: string; pollOptionB?: string } | null) => {
    setStorageItem('devground_pending_draft', draft ? JSON.stringify(draft) : null);
  },

  consumePendingDraft: (): { title: string; content: string; tags?: string[]; pollQuestion?: string; pollOptionA?: string; pollOptionB?: string } | null => {
    const raw = getStorageItem('devground_pending_draft');
    if (!raw) return null;
    setStorageItem('devground_pending_draft', null);
    try { return JSON.parse(raw); } catch { return null; }
  },

  // ── v3.0 PlayLoop Micro-BaaS & In-Game Playtest Telemetry ──
  getBaasGames: async (): Promise<any[]> => {
    try {
      const res = await fetch(`${BASE_URL}/baas/games`, { headers: ApiClient.getHeaders() });
      if (res.ok) return await res.json();
    } catch {}
    return [
      { id: 'game_shadow', title: 'Shadow Dungeon: 심연의 검', slug: 'shadow-dungeon', engine: 'Unity', developer_id: 'PixelKnight', api_key: 'dg_live_shadow_9f8a7b6c5d4e', used_cartridges: 'MOD_01 도트스튜디오,MOD_04 8비트효과음,MOD_11 셰이더사전,MOD_23 역경직계산기' },
      { id: 'game_cozy', title: 'Cozy Farm Island: 포근한 도트 농장', slug: 'cozy-farm-island', engine: 'Godot', developer_id: 'GodotCrafter', api_key: 'dg_live_cozy_3e2d1c0b9a8f', used_cartridges: 'MOD_05 칩튠브금,MOD_12 다국어번역,MOD_14 대사창에디터' },
      { id: 'game_arena', title: 'Cyber Arena 2099: 네온 메카 서바이벌', slug: 'cyber-arena-2099', engine: 'Unreal', developer_id: 'ShaderWizard', api_key: 'dg_live_arena_7c6b5a4f3e2d', used_cartridges: 'MOD_08 밸런스계산기,MOD_21 보스FSM,MOD_27 웨이브스포너' },
    ];
  },

  createBaasGame: async (data: { title: string; engine: string; used_cartridges?: string }): Promise<any> => {
    try {
      const res = await fetch(`${BASE_URL}/baas/games`, {
        method: 'POST',
        headers: ApiClient.getHeaders(),
        body: JSON.stringify(data),
      });
      if (res.ok) return await res.json();
    } catch {}
    const slug = data.title.toLowerCase().replace(/[^a-z0-9가-힣]+/g, '-') + '-' + Math.floor(100 + Math.random() * 899);
    return {
      id: 'game_' + Date.now(),
      title: data.title,
      slug,
      engine: data.engine || 'Unity',
      developer_id: ApiClient.getUsername() || 'IndieCreator',
      api_key: 'dg_live_' + Math.random().toString(16).slice(2, 14),
      used_cartridges: data.used_cartridges || 'MOD_01 도트스튜디오,MOD_04 8비트효과음',
    };
  },

  getBaasTelemetry: async (slug: string): Promise<{ game: any; leaderboard: any[]; feedbacks: any[] }> => {
    try {
      const res = await fetch(`${BASE_URL}/baas/public/games/${encodeURIComponent(slug)}/telemetry`);
      if (res.ok) return await res.json();
    } catch {}
    return {
      game: { title: slug, slug, api_key: 'dg_live_shadow_9f8a7b6c5d4e' },
      leaderboard: [
        { rank: 1, username: 'PixelKnight', score: 18450, metadata: { stage: 'Boss 4F' } },
        { rank: 2, username: 'RogueMaster', score: 15920, metadata: { stage: 'Floor 3F' } },
        { rank: 3, username: 'DotSlayer', score: 12300, metadata: { stage: 'Floor 2F' } },
      ],
      feedbacks: [
        { id: 1, type: 'REVIEW', timestampPin: '00:42 · 1층 슬라임 웨이브', message: '역경직(Hitstop) 0.08초 세팅 덕분에 평타 3타 맞출 때 손맛이 진짜 쫀득합니다!', author: 'IndieTester_KR', buildVer: 'v0.4.2-web' },
        { id: 2, type: 'SUGGESTION', timestampPin: '01:28 · 보스방 진입 직전', message: '대시 쿨타임 인디케이터가 캐릭터 발밑에도 표시되면 탄막 피할 때 시선 처리가 훨씬 편할 것 같아요.', author: 'RogueFan99', buildVer: 'v0.4.2-web' },
        { id: 3, type: 'BUG', timestampPin: '02:05 · 우측 상단 보물상자', message: '벽에 딱 붙어서 대시 공격을 쓰면 간헐적으로 타일 콜라이더 모서리에 끼입니다.', author: 'QA_Hunter', buildVer: 'v0.4.2-web' },
      ],
    };
  },

  postBaasFeedback: async (data: { slug: string; type: 'REVIEW' | 'SUGGESTION' | 'BUG'; timestampPin: string; message: string; author?: string }): Promise<any> => {
    try {
      const res = await fetch(`${BASE_URL}/baas/feedback`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) return await res.json();
    } catch {}
    return {
      id: Date.now(),
      type: data.type,
      timestampPin: data.timestampPin,
      message: data.message,
      author: data.author || ApiClient.getUsername() || 'IndieTester',
      buildVer: 'v1.0-web',
    };
  }
};
