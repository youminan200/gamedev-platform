using UnityEngine;
using UnityEngine.SceneManagement; // 씬 전환을 위해 필수

public class TitleMenuManager : MonoBehaviour
{
    // 이동할 메인 게임 씬 이름 (인스펙터에서 수정 가능)
    [SerializeField] private string mainGameSceneName = "MainGameScene";

    // START 버튼에 연결할 함수
    public void OnClickStart()
    {
        // 지정한 씬으로 화면 전환
        SceneManager.LoadScene(mainGameSceneName);
    }

    // EXIT 버튼에 연결할 함수
    public void OnClickExit()
    {
        // 1. 유니티 에디터 상에서 테스트할 때 (Play 모드 중지)
        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
        #else
        // 2. 실제 빌드된 게임 실행 파일에서 종료
        Application.Quit();
        #endif

        Debug.Log("Game Quit!");
    }
}