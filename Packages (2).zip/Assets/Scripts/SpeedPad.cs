using UnityEngine;

public class SpeedPad : MonoBehaviour
{
    [Header("부스터 설정")]
    [SerializeField] private float boostForce = 15f; // 순간 부스트 힘

    private void OnTriggerEnter(Collider other)
    {
        // 부딪힌 대상이 플레이어 공(Sphere)인지 확인
        if (other.CompareTag("Player") || other.name.Contains("Sphere"))
        {
            Rigidbody rb = other.GetComponent<Rigidbody>();
            if (rb != null)
            {
                // 공의 앞쪽 방향으로 강력한 순간 가속력(Impulse) 적용
                rb.AddForce(Vector3.forward * boostForce, ForceMode.VelocityChange);
                Debug.Log("부스터 발동!");
            }
        }
    }
}