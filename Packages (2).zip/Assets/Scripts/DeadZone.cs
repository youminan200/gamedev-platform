using UnityEngine;

public class DeadZone : MonoBehaviour
{
    [Header("리스폰 위치 (시작 지점)")]
    [SerializeField] private Vector3 respawnPosition = new Vector3(0f, 1f, 0f);

    private void OnTriggerEnter(Collider other)
    {
        // 떨어진 대상이 공(Player)인지 확인
        if (other.CompareTag("Player") || other.name.Contains("Sphere"))
        {
            Rigidbody rb = other.GetComponent<Rigidbody>();
            if (rb != null)
            {
                // 공의 회전과 속도를 0으로 초기화
                rb.linearVelocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
            }

            // 시작 위치로 순간 이동
            other.transform.position = respawnPosition;

            // 피격 사운드가 있다면 재생
            if (SoundManager.Instance != null)
            {
                SoundManager.Instance.PlayHit();
            }

            Debug.Log("공이 맵 밖으로 떨어져 리스폰되었습니다.");
        }
    }
}