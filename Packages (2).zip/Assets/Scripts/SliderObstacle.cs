using UnityEngine;

public class SliderObstacle : MonoBehaviour
{
    [SerializeField] private float speed = 3f;      // 왕복 속도
    [SerializeField] private float distance = 2.5f; // 왕복 이동 반경 (좌우 폭)

    private Vector3 startPosition;

    void Start()
    {
        // 기준 시작 위치 저장
        startPosition = transform.position;
    }

    void Update()
    {
        // -distance부터 +distance까지 PingPong 왕복 계산
        float xOffset = Mathf.PingPong(Time.time * speed, distance * 2f) - distance;
        transform.position = new Vector3(startPosition.x + xOffset, startPosition.y, startPosition.z);
    }
}