using UnityEngine;

public class Goal : MonoBehaviour
{
    [Header("클리어 UI 패널 (ClearPanel을 여기에 드래그)")]
    [SerializeField] private GameObject clearPanel;

    [Header("폭죽 파티클")]
    [SerializeField] private ParticleSystem fireworkLeft;
    [SerializeField] private ParticleSystem fireworkRight;

    private bool isCleared = false;

    private void OnTriggerEnter(Collider other)
    {
        if (isCleared) return;
        // 플레이어 공 감지
        if (!other.CompareTag("Player") && !other.name.Contains("Sphere")) return;

        isCleared = true;

        // 1. 폭죽 연출 실행
        if (fireworkLeft != null) fireworkLeft.Play();
        if (fireworkRight != null) fireworkRight.Play();

        // 2. 클리어 UI 패널 활성화 (버튼 포함)
        if (clearPanel != null)
        {
            clearPanel.SetActive(true);
        }

        // 3. 공 멈추기
        Rigidbody rb = other.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }
    }
}