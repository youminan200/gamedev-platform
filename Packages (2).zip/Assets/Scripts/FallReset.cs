using UnityEngine;

public class FallReset : MonoBehaviour
{
    [SerializeField] private GameOverManager gameOverManager;

    private void OnTriggerEnter(Collider other)
    {
        // Tag 비교 최적화: CompareTag 사용
        if (other.CompareTag("Player"))
        {
            if (gameOverManager != null)
            {
                gameOverManager.ShowGameOver();
            }
        }
    }
}