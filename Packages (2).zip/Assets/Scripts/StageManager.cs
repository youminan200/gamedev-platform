using UnityEngine;
using UnityEngine.SceneManagement;

public class StageManager : MonoBehaviour
{
    [Header("이동할 다음 스테이지 씬 이름")]
    [SerializeField] private string nextSceneName = "Stage_2";

    // NEXT STAGE 버튼 클릭 시 호출
    public void LoadNextStage()
    {
        // 골인 시 멈췄던 게임 시간 정상 복구
        Time.timeScale = 1f;

        if (!string.IsNullOrEmpty(nextSceneName))
        {
            SceneManager.LoadScene(nextSceneName);
        }
        else
        {
            Debug.LogWarning("다음 스테이지 씬 이름이 설정되지 않았습니다!");
        }
    }
}