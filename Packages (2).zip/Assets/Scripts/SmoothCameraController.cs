using UnityEngine;

public class SmoothCameraController : MonoBehaviour
{
    [Header("추적 대상")]
    [SerializeField] private Transform target; // 따라갈 플레이어(Sphere)

    [Header("카메라 위치 설정")]
    [SerializeField] private Vector3 offset = new Vector3(0f, 4.5f, -7f); // 공 뒤쪽 대각선 위 거리
    [SerializeField] private float smoothSpeed = 8f; // 따라오는 부드러움 정도 (숫자가 클수록 빠름)

    [Header("회전 시야 고정 여부")]
    [SerializeField] private bool lookAtTarget = true; // 공을 항상 내려다볼지 여부

    void LateUpdate()
    {
        if (target == null) return;

        // 목표 위치 계산 (부드러운 보간)
        Vector3 targetPosition = target.position + offset;
        transform.position = Vector3.Lerp(transform.position, targetPosition, smoothSpeed * Time.deltaTime);

        // 공을 정면으로 주시
        if (lookAtTarget)
        {
            Vector3 lookPosition = target.position + Vector3.up * 1.0f; // 공의 살짝 위쪽을 바라봄
            transform.LookAt(lookPosition);
        }
    }
}