using UnityEngine;

public class BoulderSpawner : MonoBehaviour
{
    [Header("생성할 바위 프리팹")]
    [SerializeField] private GameObject boulderPrefab;

    [Header("생성 주기(초)")]
    [SerializeField] private float spawnInterval = 3.5f;

    void Start()
    {
        // 1초 뒤 시작하여 spawnInterval마다 SpawnBoulder 실행
        InvokeRepeating(nameof(SpawnBoulder), 1f, spawnInterval);
    }

    private void SpawnBoulder()
    {
        if (boulderPrefab != null)
        {
            Instantiate(boulderPrefab, transform.position, Quaternion.identity);
        }
    }
}