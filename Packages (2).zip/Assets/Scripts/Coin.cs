using UnityEngine;

public class Coin : MonoBehaviour
{
    [Header("회전 속도")]
    [SerializeField] private float rotateSpeed = 100f;

    void Update()
    {
        // 필드에서 코인이 빙글빙글 회전하는 연출
        transform.Rotate(Vector3.up * rotateSpeed * Time.deltaTime, Space.World);
    }

    private void OnTriggerEnter(Collider other)
    {
        // 플레이어(공)와 충돌했을 때
        if (other.CompareTag("Player") || other.name.Contains("Sphere"))
        {
            // 1. 코인 효과음 재생
            if (SoundManager.Instance != null)
            {
                SoundManager.Instance.PlayCoin();
            }

            // 2. 점수 매니저가 있다면 점수 증가 호출 (선택 사항)
            // CoinManager.Instance?.AddCoin();

            // 3. 먹은 코인 오브젝트 삭제
            Destroy(gameObject);
        }
    }
}