using UnityEngine;

public class CameraController : MonoBehaviour
{
    [Header("추적할 대상 (Sphere)")]
    [SerializeField] private Transform target;

    [Header("카메라와 대상 간의 거리 오프셋")]
    [SerializeField] private Vector3 offset = new Vector3(0f, 5f, -7f);

    [Header("카메라 추적 부드러움 (낮을수록 부드러움)")]
    [SerializeField] private float smoothSpeed = 10f;

    void LateUpdate()
{
    if (target == null) return;

    // 공의 회전과 상관없이 공의 위치 + 오프셋으로만 부드럽게 추적
    Vector3 targetPosition = target.position + offset;
    transform.position = Vector3.Lerp(transform.position, targetPosition, smoothSpeed * Time.deltaTime);

    // 항상 카메라가 살짝 아래를 바라보며 공을 보게 하려면 아래 줄 추가/유지
    transform.LookAt(target.position + Vector3.up * 1f);
}
}