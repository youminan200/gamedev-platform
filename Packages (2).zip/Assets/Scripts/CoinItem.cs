using UnityEngine;

public class CoinItem : MonoBehaviour
{
    [Header("회전 속도")]
    [SerializeField] private float rotateSpeed = 120f;

    void Update()
    {
        // 제자리에서 회전하는 연출
        transform.Rotate(Vector3.up * rotateSpeed * Time.deltaTime, Space.World);
    }

    private void OnTriggerEnter(Collider other)
    {
        // 플레이어(공)와 충돌 감지
        if (other.CompareTag("Player") || other.name.Contains("Sphere"))
        {
            // 1. 코인 효과음 재생
            if (SoundManager.Instance != null)
            {
                SoundManager.Instance.PlayCoin();
            }

            // 2. 코인 점수 증가 호출
            if (CoinManager.Instance != null)
            {
                CoinManager.Instance.AddCoin(1);
            }

            // 3. 획득한 코인 오브젝트 삭제
            Destroy(gameObject);
        }
    }
}