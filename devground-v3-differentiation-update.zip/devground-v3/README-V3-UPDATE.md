# 🎮 DevGround v3.0 차별화 대규모 업데이트 패키지

## 포함된 4대 핵심 차별화 기능 (Itch.io · Game Jolt · 기존 커뮤니티 대비 독점 무기)

1. **`MOD_34 // PlayLoop 마이크로 BaaS 콘솔 & Unity/Godot SDK 생성기`**
   - 백엔드(`server/src/baas/router.ts`)가 별도 PostgreSQL 설정 없이도 **SQLite(`database.sqlite`) 기반으로 24시간 무설정 동작**하도록 업그레이드되었습니다.
   - 웹 콘솔에서 인디게임을 등록하면 고유 `X-API-Key`가 즉시 발급되며, 내 API Key가 박혀 있는 **Unity C# (`UnityWebRequest`) / Godot 4 (`HTTPRequest`) 실시간 리더보드 · 클라우드 세이브 · 인게임 피드백 전송 스크립트**를 1클릭 복사할 수 있습니다.
2. **`[02] 게임 쇼케이스` — 인게임 타임스탬프 피드백 핀(Pin) & 제작 레시피 그래프**
   - 웹 데모(`Shadow Dungeon`, `Cozy Farm Island`, `Cyber Arena 2099`) 플레이어 하단에 **실시간 타임스탬프 피드백 & 버그 핀 독(Dock)**이 탑재되어, 유저가 플레이 도중 `01:15 · 보스 2페이즈`처럼 구간을 지정해 손맛·밸런스·버그 리포트를 남기고 `+25 DevPoint`를 적립합니다.
   - 각 쇼케이스 카드에 해당 게임을 제작할 때 사용한 **공방 카트리지(`MOD_01`, `MOD_04`, `MOD_11` 등) 및 PlayLoop BaaS 레시피 배지**가 표시됩니다.
3. **`크로스 카트리지 1-Click 퍼블리싱 브릿지` (`MainFeedScreen` ➔ `PostingScreen`)**
   - 공방 도구(`MOD_34`, `MOD_35` 등)에서 생성한 SDK 코드나 게임잼 기획안을 파일로 따로 옮길 필요 없이 **`[📝 이 결과물로 개발일지 바로 쓰기 →]`** 버튼을 누르면 제목, 마크다운 코드 블록, 태그, A/B 투표 문항까지 자동으로 채워진 채 개발일지 작성 화면으로 연결됩니다.
4. **`MOD_35 // 48H 마이크로 게임잼 아레나 & 스팀 위시리스트 품앗이 부스터`**
   - 동료 개발자의 데모를 플레이테스트하거나 위시리스트를 인증해 `DevPoint`를 모으고, 내 스팀 위시리스트 및 쇼케이스 노출 순위를 상단 부스트하는 상호 성장 시스템입니다.

## 로컬 프로젝트(`E:\gamedev-platform`) 1분 반영 방법

압축을 풀고 프로젝트 루트 폴더에서 아래 명령어를 실행하세요:

```powershell
python apply_v3_update.py
git add server/src/baas/router.ts expo-client/src/api/ApiClient.ts expo-client/src/screens/PostingScreen.tsx expo-client/src/screens/MainFeedScreen.tsx
git commit -m "feat(v3.0): add PlayLoop BaaS console, in-game timestamped playtest pins, recipe graph, and 48h gamejam wishlist arena"
git push origin main
```
